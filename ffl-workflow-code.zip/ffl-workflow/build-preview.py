import json,re,pathlib
root=pathlib.Path(__file__).parent
rows=json.load(open('workflow-squads-source.json'))[1:]
hist=json.load(open('dynasty-source-20261003.json'))
short=['Broachmen','Hounds','Champs','Troopers','Jokers','Roosters','Stars','Royales','Winos','Horsen']
teams=[];players=[];squads={}; groups={}; team=''
for r in hist[1:]:
 if r[0]:team=r[0]
 groups.setdefault(team,[]).append(r)
for r in rows:
 tid=str(r[0]);pid='p'+str(len(players)+1)
 if tid not in squads:teams.append({'id':tid,'name':r[1],'short':short[len(teams)]});squads[tid]=[]
 squads[tid].append(pid)
 group=groups.get(r[1],next((g for k,g in groups.items() if 'Troopers' in k and 'Troopers' in r[1]),[]))
 # Historical normal-slot appearances are provisional: game threshold at prior drafts is not in this import.
 years=[]
 for col,year in reversed(list(enumerate(hist[0][2:],2))):
  if any(len(x)>col and x[col].strip().casefold()==r[2].strip().casefold() for x in group[:2]):years.append(year)
  else:break
 players.append({'id':pid,'name':r[2],'club':r[3],'careerGames':int(r[4]) if len(r)>4 and str(r[4]).isdigit() else None,'history':{tid:{'verified':len(years)==0,'retains':0,'recordedNormalYears':list(reversed(years))}},'historyReview':bool(years)})
logo=re.search(r'<img class="ffl-logo" src="([^"]+)"',open('ffl-ui-preview/draft-preview.html').read()).group(1)
shell=(root/'preview-shell.html').read_text()
html=shell.replace('__LOGO__',logo).replace('__ENGINE__',(root/'draft-engine.js').read_text()).replace('__FIXTURE__',json.dumps({'teams':teams,'players':players,'squads':squads},ensure_ascii=False)).replace('__UI__',(root/'preview-ui.js').read_text())
(root/'draft-workflow-preview.html').write_text(html)
print('Built preview:',len(players),'players,',len(teams),'teams;',sum(p['historyReview'] for p in players),'retention histories require historical game-count review')
